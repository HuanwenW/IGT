 python /home/huan/0-huanhuan/0-Trans+GAT/PY0607/main.py --dataset diginetica
 python /home/huan/0-huanhuan/0-Trans+GAT/PY0607/main.py --dataset yoochoose1_64
 #python /home/huan/0-huanhuan/0-Trans+GAT/PY0607/main.py --dataset yoochoose1_4
