#!/usr/bin/env python36
# -*- coding: utf-8 -*-
"""
Created on July, 2018

@author: Tangrizzly
"""

import argparse
import pickle
import time
from utils import build_graph, Data1, split_validation
from model import *

# argparse是python用于 解析命令行参数和选项 的 标准模块，用于代替已经过时的optparse模块
parser = argparse.ArgumentParser()
parser.add_argument('--dataset', default='yoochoose1_64', help='dataset name: diginetica/yoochoose1_80//yoochoose1_64/yoochoose1_48/yoochoose1_32/yoochoose1_16/yoochoose1_4/sample')
parser.add_argument('--batchSize', type=int, default=100, help='input batch size')
parser.add_argument('--hiddenSize', type=int, default=64, help='hidden state size')
parser.add_argument('--heads', type=int, default=7, help='')

parser.add_argument('--epoch', type=int, default=30, help='the number of epochs to train for')
parser.add_argument('--lr', type=float, default=0.0005, help='learning rate')  # [0.001, 0.0005, 0.0001]
parser.add_argument('--lr_dc', type=float, default=0.1, help='learning rate decay rate')
parser.add_argument('--lr_dc_step', type=int, default=5, help='the number of steps after which the learning rate decay') # [3,6]
parser.add_argument('--l2', type=float, default=1e-5, help='l2 penalty')  # [0.001, 0.0005, 0.0001, 0.00005, 0.00001]
parser.add_argument('--step', type=int, default=1, help='gnn propogation steps')
parser.add_argument('--patience', type=int, default=10, help='the number of epoch to wait before early stop ')
parser.add_argument('--nonhybrid', action='store_true', help='only use the global preference to predict')
parser.add_argument('--validation', action='store_true', help='validation')  # 用于控制验证集是否 = 测试集
parser.add_argument('--valid_portion', type=float, default=0.1, help='split the portion of training set as validation set')
# parser.add_argument('--dropout', type=float, default=0.4, help='dropout')


opt = parser.parse_args()
# 输出定义的参数
print(opt)

def main():

    train_data = pickle.load(open('../datasets/' + opt.dataset + '/train.txt', 'rb'))
    if opt.validation:# opt.validation=False
        train_data, valid_data = split_validation(train_data, opt.valid_portion) # 调用utils文件中split_validation()函数
        test_data = valid_data
    else:
        test_data = pickle.load(open('../datasets/' + opt.dataset + '/test.txt', 'rb'))
    # test_data_error(test_data)
    train_data = Data1(train_data, shuffle=False) # 调用utils文件中Data1()类,
    #print('finsh train loader')
    test_data = Data1(test_data, shuffle=False)  # 调用utils文件中Data1()类

    if opt.dataset == 'diginetica':
        n_node = 43098
    elif opt.dataset == 'yoochoose1_64' or opt.dataset == 'yoochoose1_4' or opt.dataset == 'yoochoose1_16' or opt.dataset == 'yoochoose1_32' or opt.dataset == 'yoochoose1_48'  or opt.dataset == 'yoochoose1_80':
        n_node = 37484
    else:
        n_node = 310# sample节点数
# 调用model中的SessionGraph
    model = trans_to_cuda(SessionGraph(opt, n_node))

    start = time.time()
    best_result = [0, 0]
    best_epoch = [0, 0]
    bad_counter = 0
    for epoch in range(opt.epoch):
        print('-------------------------------------------------------')
        print('epoch: ', epoch)
    #调用modle中的train_test()函数
        hit, mrr = train_test(model, train_data, test_data) # 传入model 所有参数、训练数据、测试数据
        flag = 0
        if hit >= best_result[0]:
            best_result[0] = hit
            best_epoch[0] = epoch
            flag = 1
        if mrr >= best_result[1]:
            best_result[1] = mrr
            best_epoch[1] = epoch
            flag = 1
        print('Best Result:')
        print('\tRecall@20:\t%.4f\tMMR@20:\t%.4f\tEpoch:\t%d,\t%d'% (best_result[0], best_result[1], best_epoch[0], best_epoch[1]))
        bad_counter += 1 - flag
        if bad_counter >= opt.patience:
            break
    print('-------------------------------------------------------')
    end = time.time()
    print("Run time: %f s" % (end - start))


if __name__ == '__main__':
    main()
